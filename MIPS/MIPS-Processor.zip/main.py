from MIPS import Processor
from memory import Memory
from registers import Register

mips = Processor([])

# Fills the Processor's attribute register list with 32 registers of value '0000'
# Processor's register list is initialized as emtpy in MIPS.py line 4
regCount = 32  # 32 registers
for a in range(0, regCount):
    mips.registers.append(Register("0000"))  # NULL

# Fills the Processor's attibute memory list with 32 memory of value '0000'
# Processor's memory list is initialized as empty in MIPS.py line 5
memCount = 32  # 32 memories
for b in range(0, memCount):
    mips.memory.append(Memory("0000"))  # NULL


def displayWelcome():
    header = '{:-^50}'.format("MIPS PROCESSOR")
    title = format("Xianrui Zeng's MIPS Processor for Comp Org")
    print(title)
    print()
    print(header)
    print()
    print(
        "This is a MIPS Processor that can take binary and hexadecimal instructions.\nThis prorgam takes limited instructions!"
    )


displayWelcome()

print()
print("How many instrucions: ")
count = int(input())

# Copy the input instructions to the processor's attibute instructions
for c in range(0, count):
    print(f'Enter the hex for instrucion {c+1} (in 8 bits): ')
    mips.instructions.append(input())

# Excute each insturctions in order by calling the processer's method
for d in range(0, count):
    mips.executeInstruction()

# Example: Addi: 214A0014 / 20A5FFFF / 206400AF / 20A20056
# Example: Add: 02484020 / 00441020 / 014B4820 / 00823820

# Example: 206400AF/20A20056/00823820/00822822/00821825/AD070005/8D0C0005
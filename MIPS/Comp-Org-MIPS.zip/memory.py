class Memory:
  def __init__(self, data): # Constructor
    self.data = data
  
  def overwrite(self, newValue):
     self.data = newValue
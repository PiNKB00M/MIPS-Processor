# Defination of the register object
class Register:
  # the register object consists of only one attibute: the data this register represents
  def __init__(self, data): # Constructor
    self.data = data
  # the register class consists of only one method: to change the value each register object represents
  def overwrite(self, newValue):
     self.data = newValue
import math

class Processor():
  registers = []
  memory = []
  currInstruction = 0

  def __init__(self, instructions):
    self.instructions = instructions

  # Binary to Deciaml Function
  def bintoDec(binary):
    bits = len(binary)
    dec = 0
    for i in range(bits):
      dec += (2**((bits-1)-i)) if binary[i] == "1" else 0
    return dec
  
  # Decimal to Binary Function
  def dectoBin(num):
    if(num == 0):
      return "0000"
    else:
      binary = ''
      bits = int((math.log(num) / math.log(2)) + 1); 
      remainder = num
      for i in range(1, bits+1):
        curbit = (2**(bits-i) )
        if(remainder >= curbit ):
          binary += '1'
          remainder -= curbit
        else:
          binary +='0'
      return binary
    
  # Hexadecimal to Binary Function
  def hextoBin(hexnum):
    hexChars = {
      '0': "0000",
      '1': "0001",
      '2': "0010",
      '3': "0011",
      '4': "0100",
      '5': "0101",
      '6': "0110",
      '7': "0111",
      '8': "1000",
      '9': "1001",
      'A': "1010",
      'B': "1011",
      'C': "1100",
      'D': "1101",
      'E': "1110",
      'F': "1111"
      }

    binary = ""
    for i in range(0, len(hexnum)):
      binary += hexChars[hexnum[i].upper()]
    return binary

  # Binary to Hexadecimal Function
  def bintoHex(binary):
    binBits = {
      "0000":'0',
      "0001":'1',
      "0010":'2',
      "0011":'3',
      "0100":'4',
      "0101":'5',
      "0110":'6',
      "0111":'7',
      "1000":'8',
      "1001":'9',
      "1010":'A',
      "1011":'B',
      "1100":'C',
      "1101":'D',
      "1110":'E',
      "1111":'F'
    }

    binary = binary[len(binary)::-1]

    n = 4

    bits = [binary[i:i+n] for i in range(0, len(binary), n)]

    if(len(bits[len(bits)-1]) <4):
      while (len(bits[len(bits)-1]) < 4):
       bits[len(bits)-1] += '0'

    hexnum =''

    for i in range(0, len(bits)):
      bits[i] = bits[i][len(bits[i])::-1]
      hexnum += binBits[bits[i]]
    return hexnum[len(hexnum)::-1]
  
  def getBinIns(self): # Get Binary Instruction
    return Processor.hextoBin((self.instructions[Processor.currInstruction]))

  # break up the 32 bit input instructions into corresponding components:
  #    0 - 5 is opcode
  #    6 - 10 is index of source register 1
  #    11 - 15 is index of source register 2
  #    16 - 20 is index of destination register
  #    21 - 25 is the shift value
  #    26 - 31 is the function
  #    in the case with immediate values, 16 - 31 is the address
  def getFormat(self):
    return 'R' if Processor.bintoDec(self.getBinIns()[0:6]) == 0 else "I"

  def getOp(self):
   return 0 if self.getFormat() == "R" else Processor.bintoDec(self.getBinIns()[0:6])
  
  def getFunct(self):
    return Processor.bintoDec(self.getBinIns()[26:32])

  def getAddress(self):
    return Processor.bintoDec(self.getBinIns()[16:32])
  
  def getRegisterOne(self):
    return Processor.bintoDec(self.getBinIns()[6:11])

  def getRegisterTwo(self):
    return Processor.bintoDec(self.getBinIns()[11:16])

  def getNewRegister(self): # New Destination
    return Processor.bintoDec(self.getBinIns()[16:21])
  
  def getShiftAmount(self):
    return self.getBinIns()[21:26]

  # AND function, AND operation on the values in register 1 and register 2, and stores the results in the destination register
  def andFunct(self):
    reg1 = Processor.hextoBin(Processor.registers[self.getRegisterOne()].data)

    reg2 = Processor.hextoBin(Processor.registers[self.getRegisterTwo()].data)

    regD = ""

    for i in range(0,len(reg1)):
      regD += "1" if reg1[i] == "1" and reg2[i] == "1" else "0"

    print(f'and ${self.getNewRegister()}, ${self.getRegisterOne()}, {self.getRegisterTwo()}')

    regD = Processor.bintoHex(regD)

    print(f'current ${self.getNewRegister()} data: {Processor.registers[self.getNewRegister()].data}')

    Processor.registers[self.getNewRegister()].overwrite(regD)

    print(f'new ${self.getNewRegister()} data: {Processor.registers[self.getNewRegister()].data}')

  # OR function, OR operation on the values in register 1 and register 2, and stores the results in the destination register
  def orFunct(self):
      reg1 = Processor.hextoBin(Processor.registers[self.getRegisterOne()].data)
      reg2 = Processor.hextoBin(Processor.registers[self.getRegisterTwo()].data)
      regD = ""
      for i in range(0,len(reg1)):
        regD += "1" if reg1[i] == "1" or reg2[i] == "1" else "0"
      print(f'or ${self.getNewRegister()}, ${self.getRegisterOne()}, ${self.getRegisterTwo()}')
      print(f'current ${self.getNewRegister()} data: {Processor.registers[self.getNewRegister()].data}')
      regD = Processor.bintoHex(regD)
      Processor.registers[self.getNewRegister()].overwrite(regD)
      print(f'new ${self.getNewRegister()} data: {Processor.registers[self.getNewRegister()].data}')

  # add function, adds up the values in register 1 and register 2, and stores the results in the destination register
  def add(self):
    reg1 = Processor.hextoBin(Processor.registers[self.getRegisterOne()].data)
    reg2 = Processor.hextoBin(Processor.registers[self.getRegisterTwo()].data)
    regD = Processor.bintoDec(reg1) + Processor.bintoDec(reg2)
    print(f'add ${self.getNewRegister()}, ${self.getRegisterOne()}, ${self.getRegisterTwo()}')
    print(f'# ${self.getNewRegister()} = ${self.getRegisterOne()} + {self.getRegisterTwo()}')
    print(f'current ${self.getNewRegister()} data: {Processor.registers[self.getNewRegister()].data}')
    regD = Processor.bintoHex(Processor.dectoBin(regD))
    Processor.registers[self.getNewRegister()].overwrite(regD)
    print(f'new ${self.getNewRegister()} data: {Processor.registers[self.getNewRegister()].data}')

  # subtract function, subtracts value in register 1 from the value in register 2, and stores the results in the destination register
  def sub(self):
    reg1 = Processor.hextoBin(Processor.registers[self.getRegisterOne()].data)
    reg2 = Processor.hextoBin(Processor.registers[self.getRegisterTwo()].data)
    regD = (Processor.bintoDec(reg1) - Processor.bintoDec(reg2)) 
    print(f'sub ${self.getNewRegister()}, ${self.getRegisterOne()}, ${self.getRegisterTwo()}')
    print(f'# ${self.getNewRegister()} = ${self.getRegisterOne()} + {self.getRegisterTwo()}')
    print(f'current ${self.getNewRegister()} data: {Processor.registers[self.getNewRegister()].data}')
    regD = Processor.bintoHex(Processor.dectoBin(regD))
    Processor.registers[self.getNewRegister()].overwrite(regD)
    print(f'new ${self.getNewRegister()} data: {Processor.registers[self.getNewRegister()].data}')

  # save word function, saves the value of register 2 to the location in memoery that register 1 points to 
  def sw(self):
    reg1 = Processor.hextoBin(Processor.registers[self.getRegisterOne()].data)
    reg2 = Processor.registers[self.getRegisterTwo()].data
    print(f'sw ${self.getRegisterTwo()}, {self.getAddress()}(${self.getRegisterOne()})')
    address = Processor.hextoBin(Processor.memory[self.getAddress()].data)
    offset = Processor.bintoDec(reg1) + Processor.bintoDec(address)
    print(f'current memory {offset} data: {self.memory[offset].data}')
    Processor.memory[offset].overwrite(reg2)
    print(f'new  memory {offset} data: {Processor.memory[offset].data}')

  # load word function, saves the value register 1 points to in memoty into register 2
  def lw(self):
    reg1 = Processor.hextoBin(Processor.registers[self.getRegisterOne()].data)
    reg2 = Processor.registers[self.getRegisterTwo()]
    address = Processor.hextoBin(Processor.memory[self.getAddress()].data)
    print(f'lw ${self.getRegisterTwo()}, {self.getAddress()}(${self.getRegisterOne()})')
    offset = Processor.bintoDec(reg1) + Processor.bintoDec(address)
    print(f'current ${self.getRegisterTwo()} data: {reg2.data}')
    reg2.overwrite(Processor.memory[offset].data)
    print(f'new ${self.getRegisterTwo()} data: {reg2.data}')

  # add immediate function, adds the value of register 2 and the address, and stors the results in register 1
  def addi(self):
    reg1 = Processor.registers[self.getRegisterOne()]
    reg2 = Processor.hextoBin(Processor.registers[self.getRegisterTwo()].data)
    address = self.getAddress()
    print(f'addi ${self.getRegisterTwo()}, ${self.getRegisterOne()}, {self.getAddress()}')
    summation = Processor.bintoDec(reg2) + address
    print(f'# ${self.getRegisterTwo()} = ${self.getRegisterOne()} + {self.getAddress()}')
    print(f'current ${self.getRegisterTwo()} data: {reg1.data}')
    reg1.overwrite(Processor.bintoHex(Processor.dectoBin(summation)))
    print(f'new ${self.getRegisterTwo()} data: {reg1.data}')

  def beq(self):
    reg1 = Processor.registers[self.getRegisterOne()].data
    reg2 = Processor.registers[self.getRegisterTwo()].data
    address = Processor.hextoBin(Processor.memory[self.getAddress()].data)
    print(f'beq ${self.getRegisterOne()}, ${self.getRegisterTwo()}, ${self.getAddress()}')
    Processor.memory[Processor.bintoDec(address)].overwrite("0001" if reg1 == reg2 else "0000")

  def bne(self):
    reg1 = Processor.registers[self.getRegisterOne()].data
    reg2 = Processor.registers[self.getRegisterTwo()].data
    address = Processor.hextoBin(Processor.memory[self.getAddress()].data)
    print(f'bne ${self.getRegisterOne()}, ${self.getRegisterTwo()}, ${self.getAddress()}')
    print(f'current memory {self.getAddress()} data: {Processor.memory[self.getAddress()].data}')
    Processor.memory[Processor.bintoDec(address)].overwrite("0001" if reg1 != reg2 else "0000")
    print(f'new memory {self.getAddress()} data: {Processor.memory[self.getAddress()].data}')

  def executeInstruction(self):
    print(f'\n----------{self.instructions[Processor.currInstruction]}----------')
    if (self.getFormat() == "R"):
      print("R format: 655556 ")
      funct = self.getFunct()
      if(funct == 32):
        self.add()
      elif(funct == 34):
        self.sub()
      elif(funct == 36):
        self.andFunct()
      elif(funct == 37):
        self.orFunct()
    else:
      opcode = self.getOp()
      print("I format: 65516")
      if(opcode == 35):
        self.lw()
      elif(opcode == 43):
        self.sw()
      elif(opcode == 4):
        self.beq()
      elif (opcode == 5):
        self.bne()
      elif(opcode == 8):
        self.addi()
    Processor.currInstruction += 1